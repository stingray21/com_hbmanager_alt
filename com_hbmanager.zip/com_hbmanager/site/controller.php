<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
jimport('joomla.application.component.controller');


/**
 * HB Manager Component Controller
 */
class HBmanagerController extends JController
{
	
	function display()
	{
		parent::display();
	}
} 